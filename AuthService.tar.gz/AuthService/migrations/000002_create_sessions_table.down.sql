DROP INDEX IF EXISTS idx_sessions_last_used;
DROP INDEX IF EXISTS idx_sessions_expires;
DROP INDEX IF EXISTS idx_sessions_last_used;
DROP TABLE IF EXISTS sessions;